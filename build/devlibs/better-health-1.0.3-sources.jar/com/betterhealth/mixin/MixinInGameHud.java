package com.betterhealth.mixin;

import com.betterhealth.config.BetterHealthConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Mixin(InGameHud.class)
public class MixinInGameHud {
    private static final List<FloatingNumber> floatingNumbers = new ArrayList<>();
    private static final List<HistoricalMaxEntry> historicalMax = new ArrayList<>();
    private static int lastHealth = 0;
    private static final DecimalFormat HEART_FORMAT = new DecimalFormat("0.0#");
    
    @Inject(method = "renderStatusBars", at = @At("HEAD"), cancellable = true)
    private void betterHealth$renderCustomHealthBar(DrawContext context, CallbackInfo ci) {
        BetterHealthConfig config = BetterHealthConfig.getInstance();
        
        if (!config.enabled) {
            return;
        }
        
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) {
            return;
        }

        float maxHealth = client.player.getMaxHealth();
        int threshold = config.triggerThreshold * 2;

        if (maxHealth > threshold) {
            ci.cancel();

            int screenWidth = client.getWindow().getScaledWidth();
            int screenHeight = client.getWindow().getScaledHeight();

            float currentHealth = client.player.getHealth();
            float absorption = client.player.getAbsorptionAmount();
            int hunger = MathHelper.ceil(client.player.getHungerManager().getFoodLevel());
            float saturation = client.player.getHungerManager().getSaturationLevel();
            
            float displayMax = maxHealth;
            if (config.trackHistoricalMax) {
                displayMax = getHistoricalMax(maxHealth, config.historicalMaxMinutes);
            }
            
            int barWidth = config.fullBarMode ? 182 : 81;
            int x = (screenWidth - barWidth) / 2;
            
            int barSpacing = 1;
            int baseY = screenHeight - 36;
            
            int totalBarsHeight = config.barHeight;
            if (config.showHungerBar && config.hungerBarHeight > 0) {
                totalBarsHeight += config.hungerBarHeight + barSpacing;
            }
            if (config.showSaturationBar && config.saturationBarHeight > 0) {
                totalBarsHeight += config.saturationBarHeight + barSpacing;
            }
            
            int healthBarY = baseY - totalBarsHeight + 1;
            
            int currentY = healthBarY;
            
            if (config.showSaturationBar && config.saturationBarHeight > 0) {
                int satY = currentY;
                currentY += config.saturationBarHeight + barSpacing;
                
                float satPercent = Math.min(saturation / 20f, 1.0f);
                int satWidth = (int) (barWidth * satPercent);
                
                context.fill(x - 1, satY - 1, x + barWidth + 1, satY + config.saturationBarHeight, 0xC0000000);
                context.fill(x, satY, x + barWidth, satY + config.saturationBarHeight, config.backgroundColor);
                context.fill(x, satY, x + satWidth, satY + config.saturationBarHeight, config.saturationBarColor);
            }
            
            if (config.showHungerBar && config.hungerBarHeight > 0) {
                int hungerY = currentY;
                currentY += config.hungerBarHeight + barSpacing;
                
                float hungerPercent = Math.min(hunger / 20f, 1.0f);
                int hungerWidth = (int) (barWidth * hungerPercent);
                
                context.fill(x - 1, hungerY - 1, x + barWidth + 1, hungerY + config.hungerBarHeight, 0xC0000000);
                context.fill(x, hungerY, x + barWidth, hungerY + config.hungerBarHeight, config.backgroundColor);
                context.fill(x, hungerY, x + hungerWidth, hungerY + config.hungerBarHeight, config.hungerBarColor);
            }
            
            int healthY = currentY;
            
            float healthPercent = Math.min(currentHealth / displayMax, 1.0f);
            float spentPercent = Math.max(0, Math.min((maxHealth - currentHealth) / displayMax, 1.0f - healthPercent));
            float absorptionPercent = Math.min(absorption / displayMax, 1.0f - healthPercent - spentPercent);
            
            int healthWidth = (int) (barWidth * healthPercent);
            int spentWidth = (int) (barWidth * spentPercent);
            int absorptionWidth = (int) (barWidth * absorptionPercent);
            
            context.fill(x - 1, healthY - 1, x + barWidth + 1, healthY + config.barHeight, 0xC0000000);
            context.fill(x, healthY, x + barWidth, healthY + config.barHeight, config.backgroundColor);
            
            int currentX = x;
            if (healthWidth > 0) {
                context.fill(currentX, healthY, currentX + healthWidth, healthY + config.barHeight, config.healthBarColor);
                currentX += healthWidth;
            }
            if (spentWidth > 0) {
                context.fill(currentX, healthY, currentX + spentWidth, healthY + config.barHeight, config.spentHealthColor);
                currentX += spentWidth;
            }
            if (absorptionWidth > 0) {
                context.fill(currentX, healthY, currentX + absorptionWidth, healthY + config.barHeight, config.absorptionColor);
            }
            
            String healthText = formatHealth(currentHealth, config) + "/" + formatHealth(maxHealth, config);
            if (absorption > 0) {
                healthText += " +" + formatHealth(absorption, config);
            }
            
            if (config.showHeartIcon) {
                healthText = "\u2665 " + healthText;
            }
            
            if (config.showHunger) {
                healthText += " \u00a7f\u2665" + hunger;
            }
            
            int textX = (screenWidth - client.textRenderer.getWidth(healthText)) / 2;
            int textY = healthY - 10;
            context.drawTextWithShadow(client.textRenderer, healthText, textX, textY, 0xFFFFFFFF);
            
            if (config.trackHistoricalMax) {
                trackMaxHealth(maxHealth);
            }
            
            if (config.showFloatingNumbers) {
                int healthChange = (int) (lastHealth - currentHealth);
                
                if (healthChange > 0) {
                    floatingNumbers.add(new FloatingNumber("-" + healthChange, screenWidth / 2, false));
                } else if (healthChange < 0) {
                    floatingNumbers.add(new FloatingNumber("+" + (-healthChange), screenWidth / 2, true));
                }
                
                lastHealth = (int) currentHealth;
                
                renderFloatingNumbers(context, client, screenWidth, healthY);
            }
        }
    }
    
    private String formatHealth(float health, BetterHealthConfig config) {
        if (config.showHealthAsHearts) {
            float hearts = health / 2.0f;
            if (config.showPrecision) {
                return HEART_FORMAT.format(hearts);
            } else {
                return String.valueOf((int) Math.ceil(hearts * 10) / 10.0);
            }
        } else {
            if (config.showPrecision) {
                return String.format("%." + config.precisionDigits + "f", health);
            } else {
                return String.valueOf((int) health);
            }
        }
    }
    
    private float getHistoricalMax(float currentMax, int minutes) {
        long cutoff = System.currentTimeMillis() - (minutes * 60 * 1000L);
        float max = currentMax;
        
        Iterator<HistoricalMaxEntry> iterator = historicalMax.iterator();
        while (iterator.hasNext()) {
            HistoricalMaxEntry entry = iterator.next();
            if (entry.timestamp < cutoff) {
                iterator.remove();
            } else if (entry.maxHealth > max) {
                max = entry.maxHealth;
            }
        }
        
        return Math.max(max, currentMax);
    }
    
    private void trackMaxHealth(float maxHealth) {
        if (historicalMax.isEmpty() || historicalMax.get(historicalMax.size() - 1).maxHealth != maxHealth) {
            historicalMax.add(new HistoricalMaxEntry(maxHealth, System.currentTimeMillis()));
        }
    }
    
    private void renderFloatingNumbers(DrawContext context, MinecraftClient client, int screenWidth, int barY) {
        Iterator<FloatingNumber> iterator = floatingNumbers.iterator();
        while (iterator.hasNext()) {
            FloatingNumber num = iterator.next();
            num.life--;
            
            if (num.life <= 0) {
                iterator.remove();
                continue;
            }
            
            float alpha = Math.min(1.0f, num.life / 20f);
            int color = (((int) (alpha * 255)) << 24) | (num.positive ? 0x00FF55 : 0xFF3333);
            
            float progress = 1.0f - (num.life / (float) num.maxLife);
            int offsetY = (int) (progress * 30);
            float offsetX = (float) Math.sin(progress * Math.PI * 2) * 15;
            
            int textWidth = client.textRenderer.getWidth(num.text);
            int x = num.baseX - textWidth / 2 + (int) offsetX;
            int y = barY - 25 - offsetY;
            
            context.drawTextWithShadow(client.textRenderer, num.text, x, y, color);
        }
    }
    
    private static class FloatingNumber {
        String text;
        int baseX;
        int life;
        int maxLife;
        boolean positive;
        
        FloatingNumber(String text, int baseX, boolean positive) {
            this.text = text;
            this.baseX = baseX;
            this.positive = positive;
            this.maxLife = BetterHealthConfig.getInstance().floatingNumbersDuration;
            this.life = this.maxLife;
        }
    }
    
    private static class HistoricalMaxEntry {
        float maxHealth;
        long timestamp;
        
        HistoricalMaxEntry(float maxHealth, long timestamp) {
            this.maxHealth = maxHealth;
            this.timestamp = timestamp;
        }
    }
}
