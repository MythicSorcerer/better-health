package com.betterhealth.config;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public class BetterHealthConfigScreen {
    
    public static class_437 createScreen(class_437 parent) {
        BetterHealthConfig config = BetterHealthConfig.getInstance();
        
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(class_2561.method_43470("Better Health"))
                .setSavingRunnable(config::save);
        
        ConfigCategory general = builder.getOrCreateCategory(class_2561.method_43470("General"));
        ConfigCategory display = builder.getOrCreateCategory(class_2561.method_43470("Display"));
        ConfigCategory bars = builder.getOrCreateCategory(class_2561.method_43470("Bar Settings"));
        ConfigCategory hunger = builder.getOrCreateCategory(class_2561.method_43470("Hunger Bar"));
        ConfigCategory colors = builder.getOrCreateCategory(class_2561.method_43470("Colors"));
        ConfigCategory advanced = builder.getOrCreateCategory(class_2561.method_43470("Advanced"));
        
        ConfigEntryBuilder entryBuilder = ConfigEntryBuilder.create();
        
        general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Enabled"), config.enabled)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43470("Enable or disable the custom health bar"))
                .setSaveConsumer(value -> config.enabled = value)
                .build());
        
        general.addEntry(entryBuilder.startIntSlider(class_2561.method_43470("Trigger Threshold (Hearts)"), config.triggerThreshold, 10, 100)
                .setDefaultValue(30)
                .setTooltip(class_2561.method_43470("Show custom bar when max health exceeds this many hearts"))
                .setSaveConsumer(value -> config.triggerThreshold = value)
                .build());
        
        display.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Show Heart Icon"), config.showHeartIcon)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43470("Show heart icon at start of health text"))
                .setSaveConsumer(value -> config.showHeartIcon = value)
                .build());
        
        display.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Show Health as Hearts"), config.showHealthAsHearts)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43470("Show health in hearts (0.5) instead of HP (1)"))
                .setSaveConsumer(value -> config.showHealthAsHearts = value)
                .build());
        
        display.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Show Decimal Precision"), config.showPrecision)
                .setDefaultValue(false)
                .setTooltip(class_2561.method_43470("Show decimal precision (34.5 instead of 34)"))
                .setSaveConsumer(value -> config.showPrecision = value)
                .build());
        
        display.addEntry(entryBuilder.startIntSlider(class_2561.method_43470("Precision Digits"), config.precisionDigits, 1, 3)
                .setDefaultValue(1)
                .setTooltip(class_2561.method_43470("Number of decimal places to show"))
                .setSaveConsumer(value -> config.precisionDigits = value)
                .build());
        
        bars.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Full Bar Mode"), config.fullBarMode)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43470("Full: Match hotbar width | Half: 10 hearts wide"))
                .setSaveConsumer(value -> config.fullBarMode = value)
                .build());
        
        bars.addEntry(entryBuilder.startIntSlider(class_2561.method_43470("Health Bar Height"), config.barHeight, 2, 20)
                .setDefaultValue(5)
                .setTooltip(class_2561.method_43470("Height of the main health bar"))
                .setSaveConsumer(value -> config.barHeight = value)
                .build());
        
        bars.addEntry(entryBuilder.startIntSlider(class_2561.method_43470("Hunger Bar Height"), config.hungerBarHeight, 0, 10)
                .setDefaultValue(2)
                .setTooltip(class_2561.method_43470("Height of the hunger bar (0 to disable)"))
                .setSaveConsumer(value -> config.hungerBarHeight = value)
                .build());
        
        bars.addEntry(entryBuilder.startIntSlider(class_2561.method_43470("Saturation Bar Height"), config.saturationBarHeight, 0, 10)
                .setDefaultValue(2)
                .setTooltip(class_2561.method_43470("Height of the saturation bar (0 to disable)"))
                .setSaveConsumer(value -> config.saturationBarHeight = value)
                .build());
        
        hunger.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Show Hunger Text"), config.showHunger)
                .setDefaultValue(false)
                .setTooltip(class_2561.method_43470("Show hunger number next to health"))
                .setSaveConsumer(value -> config.showHunger = value)
                .build());
        
        hunger.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Show Hunger Bar"), config.showHungerBar)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43470("Show hunger bar above health bar"))
                .setSaveConsumer(value -> config.showHungerBar = value)
                .build());
        
        hunger.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Show Saturation Bar"), config.showSaturationBar)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43470("Show saturation bar above hunger bar"))
                .setSaveConsumer(value -> config.showSaturationBar = value)
                .build());
        
        colors.addEntry(entryBuilder.startColorField(class_2561.method_43470("Health Color"), config.healthBarColor & 0x00FFFFFF)
                .setDefaultValue(0xCC1E9E1E & 0x00FFFFFF)
                .setTooltip(class_2561.method_43470("Color of the current health portion"))
                .setSaveConsumer(value -> config.healthBarColor = 0xCC000000 | value)
                .build());
        
        colors.addEntry(entryBuilder.startColorField(class_2561.method_43470("Spent Health Color"), config.spentHealthColor & 0x00FFFFFF)
                .setDefaultValue(0xCC1A1A1A & 0x00FFFFFF)
                .setTooltip(class_2561.method_43470("Color of the lost health portion"))
                .setSaveConsumer(value -> config.spentHealthColor = 0xCC000000 | value)
                .build());
        
        colors.addEntry(entryBuilder.startColorField(class_2561.method_43470("Absorption Color"), config.absorptionColor & 0x00FFFFFF)
                .setDefaultValue(0xCCFFAA00 & 0x00FFFFFF)
                .setTooltip(class_2561.method_43470("Color of absorption health (yellow)"))
                .setSaveConsumer(value -> config.absorptionColor = 0xCC000000 | value)
                .build());
        
        colors.addEntry(entryBuilder.startColorField(class_2561.method_43470("Hunger Bar Color"), config.hungerBarColor & 0x00FFFFFF)
                .setDefaultValue(0xCCCC4400 & 0x00FFFFFF)
                .setTooltip(class_2561.method_43470("Color of the hunger bar"))
                .setSaveConsumer(value -> config.hungerBarColor = 0xCC000000 | value)
                .build());
        
        colors.addEntry(entryBuilder.startColorField(class_2561.method_43470("Saturation Bar Color"), config.saturationBarColor & 0x00FFFFFF)
                .setDefaultValue(0xCCDD7700 & 0x00FFFFFF)
                .setTooltip(class_2561.method_43470("Color of the saturation bar"))
                .setSaveConsumer(value -> config.saturationBarColor = 0xCC000000 | value)
                .build());
        
        colors.addEntry(entryBuilder.startColorField(class_2561.method_43470("Background Color"), config.backgroundColor & 0x00FFFFFF)
                .setDefaultValue(0xC0000000 & 0x00FFFFFF)
                .setTooltip(class_2561.method_43470("Background color of the bars"))
                .setSaveConsumer(value -> config.backgroundColor = 0xC0000000 | value)
                .build());
        
        advanced.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Show Damage Flash"), config.showDamageFlash)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43470("Show flashing effect when taking damage"))
                .setSaveConsumer(value -> config.showDamageFlash = value)
                .build());
        
        advanced.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Show Floating Numbers"), config.showFloatingNumbers)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43470("Show damage/healing numbers floating up"))
                .setSaveConsumer(value -> config.showFloatingNumbers = value)
                .build());
        
        advanced.addEntry(entryBuilder.startIntSlider(class_2561.method_43470("Floating Numbers Duration"), config.floatingNumbersDuration, 20, 120)
                .setDefaultValue(60)
                .setTooltip(class_2561.method_43470("How long floating numbers stay visible (ticks)"))
                .setSaveConsumer(value -> config.floatingNumbersDuration = value)
                .build());
        
        advanced.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Track Historical Max"), config.trackHistoricalMax)
                .setDefaultValue(false)
                .setTooltip(class_2561.method_43470("Track your max health over time"))
                .setSaveConsumer(value -> config.trackHistoricalMax = value)
                .build());
        
        advanced.addEntry(entryBuilder.startIntSlider(class_2561.method_43470("Historical Max Time (Minutes)"), config.historicalMaxMinutes, 1, 30)
                .setDefaultValue(5)
                .setTooltip(class_2561.method_43470("How far back to track max health"))
                .setSaveConsumer(value -> config.historicalMaxMinutes = value)
                .build());
        
        return builder.build();
    }
}
