package com.betterhealth.mixin;

import com.betterhealth.BetterHealthClient;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MixinMinecraftClient {
    
    @Inject(method = "tick", at = @At("HEAD"))
    private void betterHealth$onTick(CallbackInfo ci) {
        BetterHealthClient.handleKeybinds((class_310) (Object) this);
    }
}
