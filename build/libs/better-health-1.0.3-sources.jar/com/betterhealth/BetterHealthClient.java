package com.betterhealth;

import com.betterhealth.config.BetterHealthConfig;
import com.betterhealth.config.BetterHealthConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class BetterHealthClient implements ClientModInitializer {
    private static class_304 openConfigKey;
    
    @Override
    public void onInitializeClient() {
        BetterHealthConfig.getInstance();
        
        openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.better-health.config",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_B,
                null
        ));
    }
    
    public static void handleKeybinds(class_310 client) {
        while (openConfigKey.method_1436()) {
            client.method_1507(BetterHealthConfigScreen.createScreen(client.field_1755));
        }
    }
}
