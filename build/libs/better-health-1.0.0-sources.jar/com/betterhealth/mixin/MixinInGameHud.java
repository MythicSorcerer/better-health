package com.betterhealth.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class MixinInGameHud {
    private static final int MAX_HEARTS_THRESHOLD = 30;

    @Inject(method = "renderStatusBars", at = @At("HEAD"), cancellable = true)
    private void betterhealth$renderHealthBar(class_332 context, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null || client.field_1690.field_1842) {
            return;
        }

        class_1657 player = client.field_1724;
        if (player == null) {
            return;
        }

        float currentHealth = player.method_6032();
        float maxHealth = player.method_6063();

        if (maxHealth > MAX_HEARTS_THRESHOLD * 2.0f) {
            this.renderXpBarHealth(context, client, currentHealth, maxHealth);
            ci.cancel();
        }
    }

    private void renderXpBarHealth(class_332 context, class_310 client, float currentHealth, float maxHealth) {
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        int barWidth = 182;
        int barHeight = 5;
        int x = (screenWidth - barWidth) / 2;
        int y = screenHeight - 36;

        float fillPercent = Math.min(currentHealth / maxHealth, 1.0f);
        int filledWidth = (int) (barWidth * fillPercent);

        int colorBackground = 0xC0000000;
        int colorFill = 0xCC1E9E1E;
        int colorBorder = 0xC0000000;

        context.method_25294(x - 1, y - 1, x + barWidth + 1, y + barHeight + 1, colorBorder);
        context.method_25294(x, y, x + barWidth, y + barHeight, colorBackground);
        context.method_25294(x, y, x + filledWidth, y + barHeight, colorFill);

        String healthText = (int) currentHealth + "/" + (int) maxHealth;
        int textX = (screenWidth - client.field_1772.method_1727(healthText)) / 2;
        int textY = y - 12;

        context.method_25303(client.field_1772, healthText, textX, textY, 0xFFFFFFFF);
    }
}
